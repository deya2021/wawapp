import 'package:flutter/foundation.dart';

class AppLog {
  static final List<String> _logs = [];
  static const int _maxLogs = 10;

  static void logInfo(String event, [Map<String, dynamic>? data]) {
    final message = 'INFO: $event ${data != null ? data.toString() : ''}';
    _addLog(message);
    if (kDebugMode) {
      debugPrint(message);
    }
  }

  static void logError(String event, dynamic error) {
    final message = 'ERROR: $event - $error';
    _addLog(message);
    if (kDebugMode) {
      debugPrint(message);
    }
  }

  static void _addLog(String message) {
    _logs
        .add('${DateTime.now().toIso8601String().substring(11, 19)}: $message');
    if (_logs.length > _maxLogs) {
      _logs.removeAt(0);
    }
  }

  static List<String> get logs => List.unmodifiable(_logs);
}
